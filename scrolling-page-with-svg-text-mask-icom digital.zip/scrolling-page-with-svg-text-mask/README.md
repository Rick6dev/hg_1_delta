# Scrolling Page With SVG Text Mask

A Pen created on CodePen.io. Original URL: [https://codepen.io/icomgroup/pen/GRLeQYd](https://codepen.io/icomgroup/pen/GRLeQYd).


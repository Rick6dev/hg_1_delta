# Recipe Card

A Pen created on CodePen.io. Original URL: [https://codepen.io/icomgroup/pen/BagZrKQ](https://codepen.io/icomgroup/pen/BagZrKQ).


#  Collapsible Gallery | CSS Only

A Pen created on CodePen.io. Original URL: [https://codepen.io/icomgroup/pen/BaXBdWw](https://codepen.io/icomgroup/pen/BaXBdWw).


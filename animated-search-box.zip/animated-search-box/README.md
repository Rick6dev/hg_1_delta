# Animated Search Box

A Pen created on CodePen.io. Original URL: [https://codepen.io/icomgroup/pen/NWZMgxM](https://codepen.io/icomgroup/pen/NWZMgxM).


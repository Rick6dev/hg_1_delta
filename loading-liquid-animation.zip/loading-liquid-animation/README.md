# Loading Liquid Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/icomgroup/pen/OJeaWdM](https://codepen.io/icomgroup/pen/OJeaWdM).


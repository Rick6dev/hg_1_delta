# Hover For Product Info

A Pen created on CodePen.io. Original URL: [https://codepen.io/icomgroup/pen/oNryMxN](https://codepen.io/icomgroup/pen/oNryMxN).


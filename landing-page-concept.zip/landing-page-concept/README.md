# Landing Page concept

A Pen created on CodePen.io. Original URL: [https://codepen.io/icomgroup/pen/ZEdNKZj](https://codepen.io/icomgroup/pen/ZEdNKZj).


# 3d css reveal (on hover)

A Pen created on CodePen.io. Original URL: [https://codepen.io/icomgroup/pen/vYoOwrg](https://codepen.io/icomgroup/pen/vYoOwrg).

